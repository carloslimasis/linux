# Comandos

Comando utilizado para executar comandos shell script
```sh
$ sh arquivo_comando
```